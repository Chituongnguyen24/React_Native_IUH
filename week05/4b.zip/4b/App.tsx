import React, { useMemo } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  StatusBar,
  FlatList,
  Image,
  Pressable,
  TextInput,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');
const NUM_COLUMNS = 2;
const H_PADDING = 8; // padding ngang tổng thể
const GAP = 8;       // khoảng cách giữa các card
// Tính chiều rộng card (cách đơn giản, giống lưới sát nhau trong ảnh)
const CARD_WIDTH =
  (width - H_PADDING * 2 - GAP * (NUM_COLUMNS - 1)) / NUM_COLUMNS;

type Product = {
  id: string;
  title: string;
  image: any;
  price: number;
  discountPercent: number;
  rating: number;
  reviews: number;
};

// Đổi tên file thật của bạn nếu khác (tránh khoảng trắng). Ví dụ: require('./dauchuyendoipsps2_1.png')
const DATA: Product[] = Array.from({ length: 10 }, (_, i) => ({
  id: 'p' + (i + 1),
  title: 'Cáp chuyển từ Cổng USB sang PS2 cao cấp #' + (i + 1),
  image: require('./dauchuyendoipsps2 1.png'),
  price: 69900,
  discountPercent: 39,
  rating: 4,
  reviews: 15,
}));

const formatPrice = (v: number) =>
  v.toLocaleString('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0,
  }).replace('₫', 'đ'); // đổi ký hiệu cho giống hình (đ)

const Stars = ({ value }: { value: number }) => {
  // hiển thị đầy 5 sao vàng như ảnh (không half)
  return (
    <Text style={styles.stars}>
      {'★'.repeat(5)}
    </Text>
  );
};

const ProductCard = ({ item }: { item: Product }) => {
  return (
    <Pressable style={styles.card} android_ripple={{ color: '#d5e2ef' }}>
      <Image source={item.image} style={styles.cardImage} />
      <Text style={styles.cardTitle} numberOfLines={2}>
        {item.title}
      </Text>
      <View style={styles.ratingRow}>
        <Stars value={item.rating} />
        <Text style={styles.ratingNumber}>{item.rating.toFixed(0)}</Text>
        <Text style={styles.reviewCount}>({item.reviews})</Text>
      </View>
      <View style={styles.priceBlock}>
        <Text style={styles.price}>{formatPrice(item.price)}</Text>
        <Text style={styles.discount}>-{item.discountPercent}%</Text>
      </View>
    </Pressable>
  );
};

export default function App() {
  const products = useMemo(() => DATA, []);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0A84CA" />

      {/* TOP BAR */}
      <View style={styles.topBar}>
        <Pressable style={styles.backBtn} android_ripple={{ color: '#0f6094' }}>
          <Ionicons name="arrow-back" size={20} color="#fff" />
        </Pressable>

        <View style={styles.searchWrap}>
          <Ionicons name="search" size={16} color="#2d2d2d" />
          <TextInput
            placeholder="Dây cáp usb"
            placeholderTextColor="#1e1e1e"
            style={styles.searchInput}
            returnKeyType="search"
          />
        </View>

        <View style={styles.topIcons}>
          <View style={styles.iconBadgeWrap}>
            <Ionicons name="cart-outline" size={22} color="#fff" />
            <View style={styles.badgeDot} />
          </View>
          <Pressable style={styles.iconBtn} android_ripple={{ color: '#0f6094' }}>
            <Ionicons name="ellipsis-vertical" size={20} color="#fff" />
          </Pressable>
        </View>
      </View>

      {/* PRODUCT LIST */}
      <FlatList
        data={products}
        keyExtractor={(item) => item.id}
        numColumns={NUM_COLUMNS}
        contentContainerStyle={styles.listContainer}
        columnWrapperStyle={{ gap: GAP }}
        renderItem={({ item }) => <ProductCard item={item} />}
        showsVerticalScrollIndicator={false}
      />

      {/* BOTTOM NAV */}
      <View style={styles.bottomBar}>
        <Pressable style={styles.bottomItem} android_ripple={{ color: '#d5e2ef' }}>
          <Ionicons name="menu" size={22} color="#062F4F" />
        </Pressable>
        <Pressable style={styles.bottomItemActive} android_ripple={{ color: '#d5e2ef' }}>
          <Ionicons name="home" size={24} color="#0A84CA" />
        </Pressable>
        <Pressable style={styles.bottomItem} android_ripple={{ color: '#d5e2ef' }}>
          <Ionicons name="arrow-forward" size={22} color="#062F4F" />
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: '#E5E5E5', // như ảnh
  },
  /******** TOP BAR ********/
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1ba9ff',
    paddingHorizontal: 8,
    height: 50,
  },
  backBtn: {
    padding: 6,
    borderRadius: 4,
  },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    marginHorizontal: 8,
    flex: 1,
    height: 28,
    borderRadius: 2,
    paddingHorizontal: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    paddingVertical: 0,
    marginLeft: 4,
    color: '#000',
  },
  topIcons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconBadgeWrap: {
    marginHorizontal: 6,
    padding: 4,
  },
  badgeDot: {
    position: 'absolute',
    top: 2,
    right: 4,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#FF2D55',
  },
  iconBtn: {
    padding: 6,
  },

  listContainer: {
    paddingHorizontal: H_PADDING,
    paddingTop: 8,
    paddingBottom: 70, 
  },
  card: {
    width: CARD_WIDTH,
    backgroundColor: '#fff',
    borderRadius: 2,
    padding: 4,
  },
  cardImage: {
    width: '100%',
    height: 90,
    resizeMode: 'cover',
    backgroundColor: '#d9d9d9',
  },
  cardTitle: {
    fontSize: 12,
    fontWeight: '500',
    color: '#222',
    marginTop: 4,
    lineHeight: 16,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 2,
  },
  stars: {
    fontSize: 11,
    color: '#FFB300',
    marginRight: 4,
    letterSpacing: 1,
  },
  ratingNumber: {
    fontSize: 11,
    color: '#222',
  },
  reviewCount: {
    fontSize: 11,
    color: '#222',
    marginLeft: 2,
  },
  priceBlock: {
    marginTop: 4,
  },
  price: {
    fontSize: 13,
    fontWeight: '700',
    color: '#000',
  },
  discount: {
    fontSize: 11,
    color: '#4d4d4d',
    fontWeight: '500',
    marginTop: 2,
  },

  /******** BOTTOM BAR ********/
  bottomBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 50,
    backgroundColor: '#1ba9ff',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    alignItems: 'center',
  },
  bottomItem: {
    padding: 6,
  },
  bottomItemActive: {
    padding: 6,
  },
});
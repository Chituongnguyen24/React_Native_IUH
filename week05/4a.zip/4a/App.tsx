import React from 'react';
import {View, FlatList, StyleSheet, Text, StatusBar, Image, Pressable, TouchableOpacity} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const Data = [
  {
    id: '1',
    title: 'Ca nau lau, nau mi mini...',
    shop: 'Shop Devang',
    source: require('./ca_nau_lau.png')
  },
  {
    id: '2',
    title: '1KG KHÔ GÀ BƠ TỎI...',
    shop: 'Shop LTD Food',
    source: require('./ga_bo_toi.png')
  },
  {
    id: '3',
    title: 'Xe cần cẩu đa năng',
    shop: "Shop Thế giới đồ chơi",
    source: require('./do_choi_dang_mo_hinh.png')
  },
  {
    id: '4',
    title: 'Đồ chơi dạng mô hình',
    shop: "Shop Thế giới đồ chơi",
    source: require('./do_choi_dang_mo_hinh.png')
  },
  {
    id: '5',
    title: 'Lãnh đạo giản đơn',
    shop: "Shop Minh Long Book",
    source: require('./lanh_dao_gian_don.png')
  },
  {
    id: '6',
    title: 'Hiểu lòng con trẻ',
    shop: "Shop Minh Long Book",
    source: require('./hieu_long_con_tre.png')
  },
];

type ItemProps = {
  title: string;
  shop: string;
  source: any;
  onChatPress: () => void;
};

const Item = ({title, shop, source, onChatPress}: ItemProps) => (
  <View style={styles.item}>
    <Image source={source} style={styles.image} />
    <View style={styles.itemInfo}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.shopName}>{shop}</Text>
    </View>
    <TouchableOpacity style={styles.chatButton} onPress={onChatPress}>
      <Text style={styles.chatButtonText}>Chat</Text>
    </TouchableOpacity>
  </View>
);

const App = () => {
  const handleChatPress = (item: any) => {
    console.log(`Starting chat with ${item.shop} about ${item.title}`);
    // Add your chat navigation logic here
  };

  return (
    <SafeAreaProvider>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerText}>Chat</Text>
        </View>
        
        <View style={styles.question}>
          <Text style={styles.questionText}>
            Bạn có thắc mắc với sản phẩm vừa xem. Đừng ngại chat với shop!
          </Text>
        </View>

        <SafeAreaView style={styles.listContainer}>
          <FlatList
            data={Data}
            renderItem={({item}) => (
              <Item
                source={item.source}
                title={item.title}
                shop={item.shop}
                onChatPress={() => handleChatPress(item)}
              />
            )}
            keyExtractor={item => item.id}
            showsVerticalScrollIndicator={false}
          />
        </SafeAreaView>
      </View>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1e90ff',
  },
  header: {
    backgroundColor: '#1e90ff',
    paddingTop: StatusBar.currentHeight || 44,
    paddingBottom: 15,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  headerText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
  question: {
    backgroundColor: '#e5e5e5',
    padding: 15,
  },
  questionText: {
    fontSize: 14,
    color: '#333',
    textAlign: 'left',
  },
  listContainer: {
    flex: 1,
    backgroundColor: '#e5e5e5',
  },
  item: {
    flexDirection: 'row',
    backgroundColor: 'white',
    marginVertical: 4,
    marginHorizontal: 16,
    padding: 12,
    alignItems: 'center',
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  image: {
    height: 50,
    width: 50,
    borderRadius: 4,
  },
  itemInfo: {
    flex: 1,
    marginLeft: 12,
  },
  title: {
    fontSize: 14,
    fontWeight: '400',
    color: '#333',
    marginBottom: 2,
  },
  shopName: {
    fontSize: 12,
    color: '#666',
  },
  chatButton: {
    backgroundColor: '#ff4444',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
    marginLeft: 8,
  },
  chatButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
});

export default App;
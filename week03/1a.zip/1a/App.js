import React from 'react';
import { View, Text, Pressable, StyleSheet, StatusBar } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function CheckoutScreen() {
  return (
    <LinearGradient
      colors={['#c8f4f7', '#e2f5f6', '#ffffff', '#07cdf8']}
      locations={[0, 0.56, 0.8, 1]}
      start={{ x: 0.5, y: 0 }}
      end={{ x: 0.5, y: 1 }}
      style={styles.container}
    >
      <StatusBar barStyle="dark-content" translucent backgroundColor="transparent" />
      <View style={styles.circle} />

      <View style={styles.title}>
        <Text style={styles.titletext}>Grow</Text>
        <Text style={styles.titletext}>Your Business</Text>
      </View>

      <View style={styles.centerview}>
        <Text style={styles.normaltext}>
          We will help you to grow your business using online server
        </Text>
      </View>

      <View style={styles.btngroup}>
        <Pressable style={styles.btn}>
          <Text style={styles.btntext}>Login</Text>
        </Pressable>
        <Pressable style={styles.btn}>
          <Text style={styles.btntext}>Signup</Text>
        </Pressable>

      </View>
      <View style={styles.btngroup}>
        <Text style={styles.btntext}>How We Work?</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center'
  },
  circle: {
    height: 100,
    width: 100,
    borderWidth: 10,
    borderColor: 'black',
    borderRadius: 50,
    marginBottom: 20
  },
  title: { alignItems: 'center', marginBottom: 10 },
  titletext: { fontSize: 30, fontWeight: '700' },
  centerview: { alignItems: 'center', marginHorizontal: 24, marginBottom: 20 },
  normaltext: { textAlign: 'center' },
  btngroup: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '70%',
    marginTop: 10
  },
  btn: {
    backgroundColor: '#e3c000',
    paddingVertical: 12,
    paddingHorizontal: 22,
    borderRadius: 8
  },
  btntext: { textTransform: 'uppercase', fontWeight: '600' }
});

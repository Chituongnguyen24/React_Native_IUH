import React from 'react';
import { View, Text, Pressable, StyleSheet, StatusBar,Image,TextInput,Icon } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Fontisto from '@expo/vector-icons/Fontisto';

export default function CheckoutScreen() {
  return (
    <LinearGradient
      colors={['#c8f4f7', '#e2f5f6', '#ffffff', '#07cdf8']}
      locations={[0, 0.56, 0.8, 1]}
      start={{ x: 0.5, y: 0 }}
      end={{ x: 0.5, y: 1 }}
      style={styles.container}
    >
      
      <View>
      <Image
      source={require('./assets/lock.png')}
      style={{ width: 60, height: 60 }}
    />
      </View>

      <View style={styles.title}>
        <Text style={styles.titletext}>Forget</Text>
        <Text style={styles.titletext}>Password</Text>
      </View>

      <View style={styles.centerview}>
        <Text style={styles.normaltext}>
          Provide your account's email for which you want to reset your password
        </Text>
      </View>
      <View style={styles.inputgroup}>
       <Fontisto name="email" size={24} color="black" />
      <TextInput
        style={styles.inputfield}
        placeholder="Email"
        placeholderTextColor="#333"
        keyboardType="email-address"
      />
      </View>
      <View style={styles.btngroup}>
        <Pressable style={styles.btn}>
          <Text style={styles.btntext}>Next</Text>
        </Pressable>
        

      </View>
      
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center'
  },

  title: { alignItems: 'center', marginBottom: 10 },
  titletext: { fontSize: 30, fontWeight: '700' },
  centerview: { alignItems: 'center', marginHorizontal: 24, marginBottom: 20 },
  normaltext: { textAlign: 'center' },
  btngroup: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '70%',
    marginTop: 10
  },
  btn: {
    backgroundColor: '#e3c000',
    paddingVertical: 12,
    paddingHorizontal: 22,
    borderRadius: 8,
    width:"100%",
    paddingInline:50
  },
  btntext: { 
    textTransform: 'uppercase',
    fontWeight: '600',
    textAlign:"center"
    },
  inputfield:{
    backgroundColor:"#c4c4c4",
    padding:10,

  },
  inputgroup:{
     backgroundColor:"#c4c4c4",
     flexDirection:"row",
     justifyContent:"center",
     alignItems:"center",
     paddingTop:5,
     paddingBottom:5,
     paddingInline:20,
     borderRadius:2
  }
});

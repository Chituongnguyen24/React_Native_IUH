import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Pressable
} from 'react-native';

export default function CheckoutScreen() {
  return(
    <View style={styles.container}>

    <View style={styles.circle}></View>
    <View style={styles.title}>
      <Text style={styles.titletext}>Grow</Text>
      <Text style={styles.titletext}>Your Business</Text>
    </View>
    <View style={styles.centerview}>
     <Text style={styles.normaltext}>We will help you to grow your business using online server</Text>
    </View>
    <View style={styles.btngroup}>
      <Pressable style={styles.btn}><Text style={styles.btntext}>Login</Text></Pressable>
      <Pressable style={styles.btn}><Text style={styles.btntext}>Signup</Text></Pressable>
    </View>
  </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    padding:12,
    backgroundColor:"#00ccf9",
    alignContent:"center",
    justifyContent:"center",
    alignItems:"center"
  },
  circle:{
    height:100,
    width:100,
    borderWidth:10,
    borderColor:"black",
    borderRadius:50,
    margin:40,
  },
  title:{
    alignContent:"center",
    alignItems:"center",
  },
    titletext:{
    
    fontSize:30,
    fontWeight:"bold",

  },
  centerview:{
    alignContent:"center",
    justifyContent:"center",
    alignItems:"center",
    margin:40,
  },
  normaltext:{
    textAlign:"center"
  },
  btngroup:{
    justifyContent:"space-around",
    alignContent:"center",
    flexDirection:"row",
    width:"70%",
    margin:40,
  },
  btn:{
    backgroundColor:"#e3c000",
    fontWeight:"bold",
    paddingTop: 15,
    paddingRight: 25,
    paddingBottom: 15,
    paddingLeft: 25,
    borderRadius:10,
  },
  btntext:{
    textTransform:"uppercase",
    fontWeight:600
  }
});

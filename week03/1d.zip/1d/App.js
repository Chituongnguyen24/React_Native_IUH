import React from 'react';
import { View, Text, Pressable, StyleSheet, StatusBar,Image,TextInput,Icon } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Fontisto from '@expo/vector-icons/Fontisto';

export default function CheckoutScreen() {
  return (
    <LinearGradient
      colors={['#c8f4f7', '#e2f5f6', '#ffffff', '#07cdf8']}
      locations={[0, 0.56, 0.8, 1]}
      start={{ x: 0.5, y: 0 }}
      end={{ x: 0.5, y: 1 }}
      style={styles.container}
    >
      
      <View>
      <Text style={styles.code}>Code</Text>
      </View>

      <View style={styles.title}>
      
        <Text style={styles.titletext}>Verification</Text>
      </View>

      <View style={styles.centerview}>
        <Text style={styles.normaltext}>
          Enter one-time password sent on ++8423452345234523
        </Text>
      </View>
      <View style={styles.inputgroup}>
  {[...Array(6)].map((_, index) => (
    <TextInput
      key={index}
      style={styles.inputbox}
      maxLength={1}
      keyboardType="number-pad"
    />
  ))}
</View>

      <View style={styles.btngroup}>
        <Pressable style={styles.btn}>
          <Text style={styles.btntext}>Verify code</Text>
        </Pressable>
        

      </View>
      
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center'
  },

  title: { alignItems: 'center', marginBottom: 10 },
  titletext: { fontSize: 30, fontWeight: '700' },
  centerview: { alignItems: 'center', marginHorizontal: 24, marginBottom: 20 },
  normaltext: { textAlign: 'center' },
  btngroup: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '70%',
    marginTop: 10
  },
  btn: {
    backgroundColor: '#e3c000',
    paddingVertical: 12,
    paddingHorizontal: 22,
    borderRadius: 8,
    width:"100%",
    paddingInline:50
  },
  btntext: { 
    textTransform: 'uppercase',
    fontWeight: '600',
    textAlign:"center"
    },
  inputgroup: {
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  marginVertical: 20,
  gap: 10, 
},
inputbox: {
  borderWidth: 1,
  borderColor: '#000',
  width: 40,
  height: 50,
  textAlign: 'center',
  fontSize: 20,
  borderRadius: 4,
  backgroundColor: '#fff',
},
  code:{
    textAlign:"center",
    textTransform:"uppercase",
    fontWeight:600,
    fontSize:60
  }
});

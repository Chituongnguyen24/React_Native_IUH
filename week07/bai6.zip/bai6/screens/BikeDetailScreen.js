// screens/BikeDetailScreen.js
import React from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";

export default function BikeDetailScreen({ route, navigation }) {
  const { bike } = route.params;

  return (
    <View style={styles.container}>
      <Image source={bike.image} style={styles.image} resizeMode="contain" />
      <Text style={styles.title}>{bike.title}</Text>
      <Text style={styles.discount}>15% OFF | ${bike.price}</Text>
      <Text style={styles.oldPrice}>${bike.price + 200}</Text>

      <Text style={styles.descTitle}>Description</Text>
      <Text style={styles.descText}>
        It is a very important form of writing as we write almost everything in paragraphs, 
        be it an answer, essay, story, or emails.
      </Text>

      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Add to cart</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#fff" },
  image: {
    width: "100%",
    height: 200,
    borderRadius: 20,
    backgroundColor: "#ffe8e5",
  },
  title: { fontSize: 20, fontWeight: "700", marginTop: 20 },
  discount: { color: "#666", marginTop: 5 },
  oldPrice: {
    textDecorationLine: "line-through",
    color: "#000",
    marginBottom: 20,
  },
  descTitle: { fontWeight: "700", marginBottom: 5 },
  descText: { color: "#555", marginBottom: 30 },
  button: {
    backgroundColor: "#e63946",
    paddingVertical: 12,
    borderRadius: 25,
    alignItems: "center",
  },
  buttonText: { color: "#fff", fontWeight: "700" },
});

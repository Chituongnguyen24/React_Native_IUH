// screens/BikeListScreen.js
import React, { useState } from "react";
import { View, Text, Image, FlatList, TouchableOpacity, StyleSheet } from "react-native";
import { AntDesign } from "@expo/vector-icons";

export default function BikeListScreen({ navigation }) {
  const [data, setData] = useState([
    {
      id: 1,
      title: "Pinarello",
      image: require("../bione-removebg-preview.png"),
      price: 1800,
      favorite: false,
    },
    {
      id: 2,
      title: "Pina Mountain",
      image: require("../bitwo-removebg-preview.png"),
      price: 1700,
      favorite: true,
    },
    {
      id: 3,
      title: "Pina Bike",
      image: require("../bithree_removebg-preview.png"),
      price: 1500,
      favorite: false,
    },
  ]);

  const toggleFavorite = (id) => {
    setData((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, favorite: !item.favorite } : item
      )
    );
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate("BikeDetail", { bike: item })}
    >
      <TouchableOpacity onPress={() => toggleFavorite(item.id)} style={styles.heartBtn}>
        <AntDesign
          name={item.favorite ? "heart" : "hearto"}
          size={20}
          color={item.favorite ? "red" : "#666"}
        />
      </TouchableOpacity>

      <Image source={item.image} style={styles.image} resizeMode="contain" />
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.price}>${item.price}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>The world’s Best Bike</Text>
      <FlatList
        data={data}
        numColumns={2}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderItem}
        columnWrapperStyle={{ justifyContent: "space-between" }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20,
  },
  header: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 15,
    color: "#e63946",
  },
  card: {
    backgroundColor: "#fff6f3",
    borderRadius: 15,
    padding: 10,
    width: "48%",
    marginBottom: 15,
    position: "relative",
  },
  image: {
    width: "100%",
    height: 100,
    alignSelf: "center",
  },
  title: {
    fontWeight: "600",
    textAlign: "center",
    marginTop: 10,
  },
  price: {
    textAlign: "center",
    color: "#e67e22",
    fontWeight: "500",
  },
  heartBtn: {
    position: "absolute",
    top: 10,
    right: 10,
    zIndex: 1,
  },
});

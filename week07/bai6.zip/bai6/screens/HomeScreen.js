// screens/HomeScreen.js
import React from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.subtitle}>A premium online store for</Text>
      <Text style={styles.subtitle}>sporters and their stylish choice</Text>

      <View style={styles.imageContainer}>
        <Image
          source={require("../bithree_removebg-preview.png")}
          style={styles.image}
          resizeMode="contain"
        />
      </View>

      <Text style={styles.title}>POWER BIKE SHOP</Text>

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate("BikeList")}
      >
        <Text style={styles.buttonText}>Get Started</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  subtitle: {
    color: "#333",
    fontSize: 14,
    marginBottom: 2,
    textAlign: "center",
  },
  imageContainer: {
    backgroundColor: "#ffe8e5",
    borderRadius: 30,
    marginVertical: 20,
    padding: 20,
  },
  image: {
    width: 200,
    height: 150,
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
  },
  button: {
    backgroundColor: "#e63946",
    borderRadius: 20,
    paddingHorizontal: 40,
    paddingVertical: 10,
    marginTop: 20,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "600",
  },
});

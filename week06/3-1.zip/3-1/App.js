import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ActivityIndicator,
  TouchableOpacity,
} from "react-native";
import Icon from "react-native-vector-icons/Ionicons";

export default function SingleProduct() {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  const imageMap = {
    "black": require("./assets/vs_black.png"),
    "red": require("./assets/vs_red.png"),
    "blue": require("./assets/vs_blue.png"),
    "silver": require("./assets/vs_silver.png"),
  };

  useEffect(() => {
    fetch("https://68d486d1214be68f8c6976f4.mockapi.io/phone")
      .then((res) => res.json())
      .then((data) => {
        const first = data[0]; 
        setProduct({
          ...first,
          selectedColor: first.colors[0], 
        });
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const handleColorChange = (color) => {
    setProduct((prev) => ({
      ...prev,
      selectedColor: color,
    }));
  };

  if (loading || !product) {
    return <ActivityIndicator size="large" color="blue" style={{ marginTop: 50 }} />;
  }

  return (
    <View style={styles.card}>
      <Image
        source={imageMap[product.selectedColor]}
        style={styles.image}
      />
      <Text style={styles.name}>{product.name}</Text>

      {/* Star Rating */}
      <View style={styles.ratingRow}>
        {[...Array(5)].map((_, i) => (
          <Icon
            key={i}
            name={i < product.rate ? "star" : "star-outline"}
            size={16}
            color="#FFD700"
          />
        ))}
        <Text style={styles.reviewText}> Xem {product.rate * 100} đánh giá</Text>
      </View>

      {/* Prices */}
      <View style={styles.priceRow}>
        <Text style={styles.newPrice}>{product.price} ₫</Text>
        <Text style={styles.oldPrice}>1.790.000 ₫</Text>
      </View>

      {/* Guarantee */}
      <Text style={styles.guarantee}>
        Ở đâu rẻ hơn hoàn tiền <Icon name="help-circle-outline" size={14} />
      </Text>

      {/* Chọn Màu */}
      <Text style={styles.selectText}>Chọn màu:</Text>
      <View style={styles.colorContainer}>
        {product.colors.map((color) => (
          <TouchableOpacity
            key={color}
            style={[
              styles.colorCircle,
              {
                backgroundColor: color,
                borderColor: product.selectedColor === color ? "#000" : "#ccc",
                borderWidth: product.selectedColor === color ? 2 : 1,
              },
            ]}
            onPress={() => handleColorChange(color)}
          />
        ))}
      </View>

      {/* Button */}
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 15,
    margin: 15,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
    alignItems: "center",
  },
  image: {
    width: 200,
    height: 250,
    resizeMode: "contain",
    marginBottom: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 6,
    textAlign: "center",
  },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 6,
  },
  reviewText: {
    color: "#2a80ec",
    marginLeft: 8,
    fontSize: 13,
  },
  priceRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 6,
  },
  newPrice: {
    color: "#d0021b",
    fontWeight: "bold",
    fontSize: 16,
    marginRight: 10,
  },
  oldPrice: {
    textDecorationLine: "line-through",
    color: "#888",
    fontSize: 13,
  },
  guarantee: {
    fontSize: 13,
    color: "#d0021b",
    marginBottom: 10,
  },
  selectText: {
    marginTop: 10,
    marginBottom: 5,
    fontWeight: "bold",
  },
  colorContainer: {
    flexDirection: "row",
    marginBottom: 10,
  },
  colorCircle: {
    width: 30,
    height: 30,
    borderRadius: 15,
    marginHorizontal: 5,
  },
  button: {
    backgroundColor: "#e30019",
    borderRadius: 4,
    paddingVertical: 10,
    paddingHorizontal: 30,
    alignItems: "center",
    marginTop: 10,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
});

import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  FlatList
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Ionicons from 'react-native-vector-icons/Ionicons';

const Stack = createStackNavigator();

/* ========== CÁC MAP ẢNH & TÊN MÀU ========== */
const imageMap = {
  black: require('./assets/vs_black.png'),
  red: require('./assets/vs_red.png'),
  blue: require('./assets/vs_blue.png'),
  silver: require('./assets/vs_silver.png'),
};
const colorNames = {
  black: 'Đen',
  red: 'Đỏ',
  blue: 'Xanh dương',
  silver: 'Bạc',
};

/* ========== SCREEN 1 & 4: PRODUCT (TRƯỚC & SAU KHI CHỌN MÀU) ========== */
function ProductScreen({ navigation, route }) {
  const [product, setProduct] = useState(null);
  const [loading, setLoading]   = useState(true);

  // Lấy màu được chọn từ route.params (nếu có)
  const selectedColorFromParams = route.params?.selectedColor;

  useEffect(() => {
    fetch('https://68d486d1214be68f8c6976f4.mockapi.io/phone')
      .then(r => r.json())
      .then(data => {
        const first = data[0];
        setProduct(prev => ({
          ...first,
          selectedColor: selectedColorFromParams || first.colors[0],
        }));
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [selectedColorFromParams]);

  if (loading || !product) {
    return (
      <SafeAreaView style={{ flex: 1, justifyContent: 'center' }}>
        <ActivityIndicator size="large" color="#0066cc" />
      </SafeAreaView>
    );
  }

  const goSelectColor = () => {
    navigation.navigate('ColorSelect', {
      product,
      selectedColor: product.selectedColor
    });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.screenPadding}>

        <View style={styles.productCard}>
          {/* Vùng ảnh 2 cột giống layout hình bạn */}
            <View style={styles.imagesRow}>
              <Image
                source={imageMap[product.colors[0]]}
                style={styles.productSmallImage}
              />
              <Image
                source={imageMap[product.selectedColor]}
                style={styles.productSmallImage}
              />
            </View>

          <Text style={styles.productTitle}>{product.name}</Text>

            {/* Rating + Reviews */}
            <View style={styles.ratingRow}>
              {[...Array(5)].map((_, i) => (
                <Ionicons
                  key={i}
                  name={i < Math.floor(product.rate) ? 'star' : 'star-outline'}
                  size={14}
                  color="#FFD700"
                />
              ))}
              <Text style={styles.reviewCount}>|  Xem {Math.floor(product.rate * 100)} đánh giá</Text>
            </View>

            {/* Price row */}
            <View style={styles.priceRow}>
              <Text style={styles.newPrice}>{product.price} ₫</Text>
              <Text style={styles.oldPrice}>1.790.000 ₫</Text>
              <View style={styles.discountBadge}>
                <Text style={styles.discountText}>-20%</Text>
              </View>
            </View>

            <Text style={styles.soldText}>Đã bán {Math.floor(product.rate * 1000)}</Text>

            {/* Nút chọn màu (giống thanh dropdown) */}
            <TouchableOpacity style={styles.colorDropdown} onPress={goSelectColor}>
              <Text style={styles.colorDropdownText}>
                {colorNames[product.selectedColor]} - CHỌN MÀU
              </Text>
              <Ionicons name="chevron-down" size={18} color="#333" />
            </TouchableOpacity>

            {/* Nút CHỌN MUA */}
            <TouchableOpacity style={styles.buyButton}>
              <Text style={styles.buyButtonText}>CHỌN MUA</Text>
            </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}


/* ========== SCREEN 2 & 3: CHỌN MÀU ========== */
function ColorSelectScreen({ route, navigation }) {
  const { product, selectedColor } = route.params;
  const [currentColor, setCurrentColor] = useState(selectedColor);

  const renderColorItem = ({ item }) => {
    const isActive = item === currentColor;
    return (
      <TouchableOpacity
        style={[
          styles.colorBlock,
          { backgroundColor: item },
          isActive && styles.colorBlockActive
        ]}
        onPress={() => setCurrentColor(item)}
        activeOpacity={0.7}
      />
    );
  };

  const confirm = () => {
    // Điều hướng về ProductScreen với màu mới
    navigation.navigate('Product', { selectedColor: currentColor });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.selectCardWrapper}>
        <View style={styles.selectCard}>
          {/* Header Back */}
          <View style={styles.selectHeader}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
              <Ionicons name="arrow-back" size={22} color="#000" />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Chọn màu</Text>
          </View>

          {/* Khối thông tin trên nền trắng */}
          <View style={styles.topInfoRow}>
            <Image
              source={imageMap[currentColor]}
              style={styles.topInfoImage}
            />
            <View style={{ flex: 1, paddingRight: 4 }}>
              <Text style={styles.topInfoName} numberOfLines={2}>{product.name}</Text>
              <Text style={styles.topInfoPrice}>{product.price} ₫</Text>
              <Text style={styles.topInfoSupplier}>Cung cấp bởi Tiki Trading</Text>
            </View>
          </View>

          {/* Phần nền xám + danh sách màu */}
          <View style={styles.grayArea}>
            <Text style={styles.grayTitle}>Chọn một màu bên dưới:</Text>
            <FlatList
              data={product.colors}
              keyExtractor={(c) => c}
              renderItem={renderColorItem}
              contentContainerStyle={styles.colorListContainer}
              showsVerticalScrollIndicator={false}
            />
          </View>

          {/* Nút XONG */}
          <TouchableOpacity style={styles.doneBtn} onPress={confirm}>
            <Text style={styles.doneBtnText}>XONG</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}


/* ========== APP ROOT ========== */
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
        <Stack.Screen name="Product" component={ProductScreen} />
        <Stack.Screen name="ColorSelect" component={ColorSelectScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}


/* ========== STYLES ========== */
const CARD_BORDER = '#e5e5e5';
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f2f2f2' },
  screenPadding: { padding: 16 },
  productCard: {
    backgroundColor: '#fff',
    borderRadius: 4,
    padding: 14,
    borderWidth: 1,
    borderColor: CARD_BORDER
  },
  imagesRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10
  },
  productSmallImage: {
    width: '48%',
    height: 180,
    resizeMode: 'contain',
    backgroundColor: '#ffffff'
  },
  productTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#222',
    marginBottom: 6
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6
  },
  reviewCount: {
    fontSize: 11,
    color: '#555',
    marginLeft: 8
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4
  },
  newPrice: {
    color: '#d70018',
    fontWeight: '700',
    fontSize: 16,
    marginRight: 10
  },
  oldPrice: {
    color: '#888',
    textDecorationLine: 'line-through',
    fontSize: 12,
    marginRight: 8
  },
  discountBadge: {
    backgroundColor: '#d70018',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 3
  },
  discountText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '600'
  },
  soldText: {
    fontSize: 11,
    color: '#444',
    marginBottom: 12
  },
  colorDropdown: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 4,
    paddingHorizontal: 10,
    paddingVertical: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14
  },
  colorDropdownText: {
    fontSize: 12,
    color: '#222',
    fontWeight: '500'
  },
  buyButton: {
    backgroundColor: '#e50000',
    paddingVertical: 14,
    borderRadius: 4,
    alignItems: 'center'
  },
  buyButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700'
  },

  /* Color Select */
  selectCardWrapper: {
    flex: 1,
    padding: 16
  },
  selectCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 4,
    borderWidth: 1,
    borderColor: CARD_BORDER,
    overflow: 'hidden'
  },
  selectHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: CARD_BORDER
  },
  backBtn: { padding: 4 },
  headerTitle: { fontSize: 16, fontWeight: '600', marginLeft: 8 },

  topInfoRow: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: CARD_BORDER,
    backgroundColor: '#fff'
  },
  topInfoImage: {
    width: 70,
    height: 90,
    resizeMode: 'contain',
    marginRight: 12
  },
  topInfoName: { fontSize: 13, fontWeight: '500', color: '#222', marginBottom: 4 },
  topInfoPrice: { fontSize: 15, fontWeight: '700', color: '#d70018', marginBottom: 4 },
  topInfoSupplier: { fontSize: 11, color: '#555' },

  grayArea: {
    flex: 1,
    backgroundColor: '#d9d9d9',
    paddingHorizontal: 16,
    paddingTop: 14
  },
  grayTitle: {
    fontSize: 13,
    fontWeight: '500',
    color: '#222',
    marginBottom: 14
  },
  colorListContainer: {
    paddingBottom: 100
  },
  colorBlock: {
    width: '100%',
    height: 70,
    borderRadius: 4,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: 'transparent'
  },
  colorBlockActive: {
    borderColor: '#333'
  },
  doneBtn: {
    backgroundColor: '#2f65c7',
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center'
  },
  doneBtnText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700'
  }
});
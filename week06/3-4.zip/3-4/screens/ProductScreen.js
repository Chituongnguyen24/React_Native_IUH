import React, { useState, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

const imageMap = {
  black: require('./assets/vs_black.png'),
  red: require('./assets/vs_red.png'),
  blue: require('./assets/vs_blue.png'),
  silver: require('./assets/vs_silver.png'),
};
const colorNames = {
  black: 'Đen',
  red: 'Đỏ',
  blue: 'Xanh dương',
  silver: 'Bạc',
};

export default function ProductScreen({ navigation, route }) {
  const [product, setProduct] = useState(null);

  useEffect(() => {
    fetch("https://68d486d1214be68f8c6976f4.mockapi.io/phone")
      .then((res) => res.json())
      .then((data) => {
        const first = data[0];
        setProduct({
          ...first,
          selectedColor: route.params?.selectedColor || first.colors[0],
        });
      });
  }, [route.params?.selectedColor]);

  if (!product) return null;

  return (
    <View style={styles.container}>
      <Image source={imageMap[product.selectedColor]} style={styles.image} />
      <Text style={styles.name}>{product.name}</Text>
      <View style={styles.ratingRow}>
        {[...Array(5)].map((_, i) => (
          <Icon
            key={i}
            name={i < Math.floor(product.rate) ? "star" : "star-outline"}
            size={14}
            color="#FFD700"
          />
        ))}
        <Text style={styles.reviewText}>(Xem {Math.floor(product.rate * 100)} đánh giá)</Text>
      </View>
      <View style={styles.priceRow}>
        <Text style={styles.newPrice}>{product.price} ₫</Text>
        <Text style={styles.oldPrice}>1.790.000 ₫</Text>
        <View style={styles.discountBadge}>
          <Text style={styles.discountText}>-20%</Text>
        </View>
      </View>
      <TouchableOpacity
        style={styles.colorSelectionButton}
        onPress={() =>
          navigation.navigate("ColorSelect", {
            product,
            selectedColor: product.selectedColor
          })
        }
      >
        <Text style={styles.selectText}>{product.colors.length} MÀU-CHỌN MÀU</Text>
        <Icon name="chevron-forward" size={20} color="#666" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );
}

// styles giống như file bạn gửi (bỏ qua để ngắn gọn)
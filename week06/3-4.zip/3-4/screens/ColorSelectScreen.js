import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, Image, StyleSheet, ActivityIndicator } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';

const STORE = { favorites: [] };
const AsyncStorage = {
  getItem: async (key) => {
    return JSON.stringify(STORE[key] || []);
  },
  setItem: async (key, value) => {
    STORE[key] = JSON.parse(value);
  },
};

const imageMap = {
  black: require(""),
  red: require('./assets/vs_red.png'),
  blue: require('./assets/vs_blue.png'),
  silver: require('./assets/vs_silver.png'),
};

function ProductsScreen({ navigation }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://68d486d1214be68f8c6976f4.mockapi.io/phone")
      .then((res) => res.json())
      .then((data) => {
        setProducts(data);
        setLoading(false);
      });
  }, []);

  const addToFavorites = async (item) => {
    let favs = await AsyncStorage.getItem('favorites');
    favs = favs ? JSON.parse(favs) : [];
    if (!favs.find(f => f.id === item.id)) {
      favs.push(item);
      await AsyncStorage.setItem('favorites', JSON.stringify(favs));
      alert('Đã lưu vào Favorites!');
    } else {
      alert('Sản phẩm đã có trong Favorites!');
    }
  };

  if (loading) return <ActivityIndicator size="large" color="#0066cc" style={{ flex: 1, justifyContent: 'center' }} />;

  return (
    <View style={styles.container}>
      <FlatList
        data={products}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() => navigation.navigate('ProductDetails', { id: item.id })}
          >
            <Image source={imageMap[item.colors[0]]} style={styles.image} />
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.price}>{item.price} ₫</Text>
            </View>
            <TouchableOpacity onPress={() => addToFavorites(item)}>
              <Text style={styles.save}>Lưu</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

function FavoritesScreen({ navigation }) {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    const fetchFavs = async () => {
      let favs = await AsyncStorage.getItem('favorites');
      setFavorites(favs ? JSON.parse(favs) : []);
    };
    const unsubscribe = navigation.addListener('focus', fetchFavs);
    return unsubscribe;
  }, [navigation]);

  return (
    <View style={styles.container}>
      <FlatList
        data={favorites}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() => navigation.navigate('ProductDetails', { id: item.id })}
          >
            <Image source={imageMap[item.colors[0]]} style={styles.image} />
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.price}>{item.price} ₫</Text>
            </View>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<Text style={{ textAlign: 'center', marginTop: 20 }}>Chưa có sản phẩm yêu thích</Text>}
      />
    </View>
  );
}

function ProductDetails({ route }) {
  const { id } = route.params;
  const [product, setProduct] = useState(null);

  useEffect(() => {
    fetch("https://68d486d1214be68f8c6976f4.mockapi.io/phone/" + id)
      .then((res) => res.json())
      .then((data) => setProduct(data));
  }, [id]);

  if (!product) return <ActivityIndicator size="large" color="#0066cc" style={{ flex: 1, justifyContent: 'center' }} />;

  return (
    <View style={styles.detailsContainer}>
      <Image source={imageMap[product.colors[0]]} style={styles.detailsImage} />
      <Text style={styles.detailsName}>{product.name}</Text>
      <Text style={styles.detailsPrice}>{product.price} ₫</Text>
      <Text style={styles.detailsDesc}>Màu sắc: {product.colors.join(', ')}</Text>
      <Text style={styles.detailsDesc}>Rate: {product.rate}</Text>
    </View>
  );
}

const Tab = createBottomTabNavigator();
function HomeTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          if (route.name === 'Products') iconName = 'list-outline';
          else if (route.name === 'Favorites') iconName = 'heart-outline';
          return <Ionicons name={iconName} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Products" component={ProductsScreen} options={{ title: 'Products' }} />
      <Tab.Screen name="Favorites" component={FavoritesScreen} options={{ title: 'Favorites' }} />
    </Tab.Navigator>
  );
}

const Stack = createStackNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="HomeTabs" component={HomeTabs} options={{ title: 'Home', headerShown: false }} />
        <Stack.Screen name="ProductDetails" component={ProductDetails} options={{ title: 'Chi tiết sản phẩm' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  item: { flexDirection: "row", alignItems: "center", padding: 12, borderBottomWidth: 1, borderBottomColor: "#eee" },
  image: { width: 60, height: 70, resizeMode: "contain", marginRight: 12 },
  name: { fontSize: 16, fontWeight: "500" },
  price: { fontSize: 14, color: "#e74c3c" },
  save: { color: "#0066cc", fontWeight: "bold", padding: 10 },
  detailsContainer: { flex: 1, alignItems: "center", padding: 20, backgroundColor: "#fff" },
  detailsImage: { width: 180, height: 220, resizeMode: "contain", marginBottom: 16 },
  detailsName: { fontSize: 20, fontWeight: "bold", marginBottom: 8 },
  detailsPrice: { fontSize: 18, color: "#e74c3c", marginBottom: 8 },
  detailsDesc: { fontSize: 16, marginBottom: 6 },
});
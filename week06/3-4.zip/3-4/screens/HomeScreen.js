import React, { useState, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, ActivityIndicator, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

const imageMap = {
  black: require('./assets/vs_black.png'),
  red: require('./assets/vs_red.png'),
  blue: require('./assets/vs_blue.png'),
  silver: require('./assets/vs_silver.png'),
};
const colorNames = {
  black: 'Đen',
  red: 'Đỏ',
  blue: 'Xanh dương',
  silver: 'Bạc',
};

export default function ProductScreen({ navigation, route }) {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://68d486d1214be68f8c6976f4.mockapi.io/phone")
      .then((res) => res.json())
      .then((data) => {
        const first = data[0];
        setProduct({
          ...first,
          selectedColor: route.params?.selectedColor || first.colors[0],
        });
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [route.params?.selectedColor]);

  if (loading || !product) {
    return <ActivityIndicator size="large" color="#0066cc" style={{ flex: 1, justifyContent: 'center' }} />;
  }

  return (
    <View style={styles.container}>
      <Image source={imageMap[product.selectedColor]} style={styles.image} />
      <Text style={styles.name}>{product.name}</Text>
      <View style={styles.ratingRow}>
        {[...Array(5)].map((_, i) => (
          <Icon
            key={i}
            name={i < Math.floor(product.rate) ? "star" : "star-outline"}
            size={14}
            color="#FFD700"
          />
        ))}
        <Text style={styles.reviewText}>(Xem {Math.floor(product.rate * 100)} đánh giá)</Text>
      </View>
      <View style={styles.priceRow}>
        <Text style={styles.newPrice}>{product.price} ₫</Text>
        <Text style={styles.oldPrice}>1.790.000 ₫</Text>
        <View style={styles.discountBadge}>
          <Text style={styles.discountText}>-20%</Text>
        </View>
      </View>
      <TouchableOpacity
        style={styles.colorSelectionButton}
        onPress={() =>
          navigation.navigate("ColorSelect", {
            product,
            selectedColor: product.selectedColor
          })
        }
      >
        <Text style={styles.selectText}>{product.colors.length} MÀU-CHỌN MÀU</Text>
        <Icon name="chevron-forward" size={20} color="#666" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f8f8f8" },
  image: { width: 180, height: 220, resizeMode: "contain", alignSelf: "center", marginTop: 20, marginBottom: 10 },
  name: { fontSize: 16, fontWeight: "400", marginBottom: 8, marginHorizontal: 20, color: "#333" },
  ratingRow: { flexDirection: "row", alignItems: "center", marginBottom: 8, marginHorizontal: 20 },
  reviewText: { color: "#666", marginLeft: 6, fontSize: 12 },
  priceRow: { flexDirection: "row", alignItems: "center", marginBottom: 8, marginHorizontal: 20 },
  newPrice: { color: "#e74c3c", fontWeight: "bold", fontSize: 18, marginRight: 15 },
  oldPrice: { textDecorationLine: "line-through", color: "#999", fontSize: 14, marginRight: 10 },
  discountBadge: { backgroundColor: "#e74c3c", paddingHorizontal: 6, paddingVertical: 2, borderRadius: 3 },
  discountText: { color: "#fff", fontSize: 12, fontWeight: "bold" },
  colorSelectionButton: {
    flexDirection: "row", justifyContent: "space-between", alignItems: "center",
    paddingVertical: 15, paddingHorizontal: 20,
    borderTopWidth: 1, borderBottomWidth: 1, borderColor: "#eee",
    marginBottom: 20
  },
  selectText: { fontSize: 14, fontWeight: "500", color: "#333" },
  button: {
    backgroundColor: "#e74c3c", borderRadius: 6, paddingVertical: 12,
    alignItems: "center", marginHorizontal: 20, marginBottom: 20
  },
  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
});
import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  FlatList,
  Platform
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Ionicons from 'react-native-vector-icons/Ionicons';

const Stack = createStackNavigator();

/* ========= ẢNH ========= */
const frontImageMap = {
  black: require('./assets/vs_black.png'),
  red: require('./assets/vs_red.png'),
  blue: require('./assets/vs_blue.png'),
  silver: require('./assets/vs_silver.png'),
};

// Nếu có ảnh mặt sau thì thêm ở đây (hoặc để trống sẽ fallback):
const backImageMap = {
  black: (() => { try { return require('./assets/vs_black_back.png'); } catch { return null; } })(),
  red: (() => { try { return require('./assets/vs_red_back.png'); } catch { return null; } })(),
  blue: (() => { try { return require('./assets/vs_blue_back.png'); } catch { return null; } })(),
  silver: (() => { try { return require('./assets/vs_silver_back.png'); } catch { return null; } })(),
};

const colorNames = {
  black: 'Đen',
  red: 'Đỏ',
  blue: 'Xanh dương',
  silver: 'Bạc',
};

/* ========= SCREEN 1 & 4: PRODUCT ========= */
function ProductScreen({ navigation, route }) {
  const chosenColor = route.params?.selectedColor; // màu quay về
  const [product, setProduct] = useState(null);
  const [loading, setLoading]  = useState(true);

  useEffect(() => {
    fetch('https://68d486d1214be68f8c6976f4.mockapi.io/phone')
      .then(r => r.json())
      .then(data => {
        const first = data[0];
        setProduct(prev => ({
          ...first,
          selectedColor: chosenColor || first.colors[0],
        }));
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [chosenColor]);

  if (loading || !product) {
    return (
      <SafeAreaView style={styles.fullCenter}>
        <ActivityIndicator size="large" color="#0066cc" />
      </SafeAreaView>
    );
  }

  const currentColor = product.selectedColor;
  const frontImg = frontImageMap[currentColor];
  const backImg  = backImageMap[currentColor] || frontImageMap[currentColor];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.outerScrollArea}>
        <View style={styles.productCard}>
          {/* Hai ảnh lớn */}
          <View style={styles.bigImagesRow}>
            <Image source={frontImg} style={styles.bigImage} />
            <Image source={backImg}  style={styles.bigImage} />
          </View>

          <Text style={styles.prodTitle}>{product.name}</Text>

          {/* Rating row */}
          <View style={styles.ratingRow}>
            {[...Array(5)].map((_, i) => (
              <Ionicons
                key={i}
                name={i < Math.floor(product.rate) ? 'star' : 'star-outline'}
                size={14}
                color="#FFD700"
              />
            ))}
            <Text style={styles.reviewMeta}>  •  Xem {Math.floor(product.rate * 100)} đánh giá</Text>
          </View>

            {/* Price row */}
            <View style={styles.priceRow}>
              <Text style={styles.newPrice}>{product.price} ₫</Text>
              <Text style={styles.oldPrice}>1.790.000 ₫</Text>
              <View style={styles.discountBadge}>
                <Text style={styles.discountText}>-20%</Text>
              </View>
            </View>

            <Text style={styles.soldText}>Đã bán {Math.floor(product.rate * 1000)}</Text>

            {/* Nút chọn màu */}
            <TouchableOpacity
              style={styles.colorSelectBar}
              onPress={() =>
                navigation.navigate('ColorSelect', {
                  product,
                  selectedColor: currentColor
                })
              }
            >
              <Text style={styles.colorSelectText}>
                {colorNames[currentColor]} - CHỌN MÀU
              </Text>
              <Ionicons name="chevron-down" size={18} color="#222" />
            </TouchableOpacity>

            {/* Nút CHỌN MUA */}
            <TouchableOpacity style={styles.buyButton}>
              <Text style={styles.buyButtonText}>CHỌN MUA</Text>
            </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

/* ========= SCREEN 2 & 3: CHỌN MÀU ========= */
function ColorSelectScreen({ route, navigation }) {
  const { product, selectedColor } = route.params;
  const [currentColor, setCurrentColor] = useState(selectedColor);

  const frontImg = frontImageMap[currentColor];

  const confirm = () => {
    navigation.navigate('Product', { selectedColor: currentColor });
  };

  const renderColor = ({ item }) => {
    const active = item === currentColor;
    return (
      <TouchableOpacity
        onPress={() => setCurrentColor(item)}
        activeOpacity={0.65}
        style={[
          styles.colorBlock,
          { backgroundColor: item },
          active && styles.colorBlockActive
        ]}
      />
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.selectWrapper}>
        <View style={styles.selectCard}>
          {/* Header */}
          <View style={styles.headerRow}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.headerBackBtn}>
              <Ionicons name="arrow-back" size={22} color="#000" />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Chọn màu</Text>
          </View>

          {/* Strip trắng */}
          <View style={styles.infoStrip}>
            <Image source={frontImg} style={styles.stripImage} />
            <View style={{ flex: 1 }}>
              <Text style={styles.stripName} numberOfLines={2}>{product.name}</Text>
              <Text style={styles.stripPrice}>{product.price} ₫</Text>
              <Text style={styles.stripSupplier}>Cung cấp bởi Tiki Trading</Text>
              <Text style={styles.stripColor}>Màu: {colorNames[currentColor]}</Text>
            </View>
          </View>

          {/* Thân xám */}
          <View style={styles.grayBody}>
            <Text style={styles.grayTitle}>Chọn một màu bên dưới:</Text>

            <FlatList
              data={product.colors}
              keyExtractor={(c) => c}
              renderItem={renderColor}
              contentContainerStyle={{ paddingBottom: 120 }}
              showsVerticalScrollIndicator={false}
            />
          </View>

          {/* Nút XONG */}
          <TouchableOpacity style={styles.doneButton} onPress={confirm}>
            <Text style={styles.doneText}>XONG</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

/* ========= ROOT ========= */
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerShown:false,
          animation: Platform.OS === 'ios' ? 'default' : 'slide_from_right'
        }}
      >
        <Stack.Screen name="Product" component={ProductScreen} />
        <Stack.Screen name="ColorSelect" component={ColorSelectScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

/* ========= STYLES ========= */
const BORDER = '#e4e4e4';
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor:'#ececec' },
  fullCenter: { flex:1, justifyContent:'center', alignItems:'center' },

  /* Product card */
  outerScrollArea: {
    padding: 18
  },
  productCard: {
    backgroundColor:'#fff',
    borderRadius:4,
    borderWidth:1,
    borderColor:BORDER,
    paddingHorizontal:14,
    paddingVertical:16
  },
  bigImagesRow:{
    flexDirection:'row',
    justifyContent:'space-between',
    marginBottom:12
  },
  bigImage:{
    width:'48%',
    height:190,
    resizeMode:'contain'
  },
  prodTitle:{
    fontSize:14,
    fontWeight:'500',
    color:'#222',
    marginBottom:6
  },
  ratingRow:{
    flexDirection:'row',
    alignItems:'center',
    marginBottom:6
  },
  reviewMeta:{
    fontSize:11,
    color:'#555',
    marginLeft:6
  },
  priceRow:{
    flexDirection:'row',
    alignItems:'center',
    marginBottom:4
  },
  newPrice:{
    fontSize:16,
    fontWeight:'700',
    color:'#d70018',
    marginRight:10
  },
  oldPrice:{
    fontSize:12,
    color:'#888',
    textDecorationLine:'line-through',
    marginRight:8
  },
  discountBadge:{
    backgroundColor:'#d70018',
    paddingHorizontal:6,
    paddingVertical:2,
    borderRadius:3
  },
  discountText:{
    color:'#fff',
    fontSize:11,
    fontWeight:'600'
  },
  soldText:{
    fontSize:11,
    color:'#444',
    marginBottom:12
  },
  colorSelectBar:{
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'space-between',
    borderWidth:1,
    borderColor:'#ccc',
    borderRadius:4,
    paddingHorizontal:10,
    paddingVertical:10,
    marginBottom:14
  },
  colorSelectText:{
    fontSize:12,
    fontWeight:'500',
    color:'#222'
  },
  buyButton:{
    backgroundColor:'#d70018',
    paddingVertical:14,
    borderRadius:4,
    alignItems:'center'
  },
  buyButtonText:{
    color:'#fff',
    fontSize:14,
    fontWeight:'700'
  },

  /* Select screen */
  selectWrapper:{
    flex:1,
    padding:18
  },
  selectCard:{
    flex:1,
    backgroundColor:'#fff',
    borderRadius:4,
    borderWidth:1,
    borderColor:BORDER,
    overflow:'hidden'
  },
  headerRow:{
    flexDirection:'row',
    alignItems:'center',
    paddingHorizontal:10,
    paddingVertical:8,
    borderBottomWidth:1,
    borderBottomColor:BORDER
  },
  headerBackBtn:{ padding:4 },
  headerTitle:{ fontSize:16, fontWeight:'600', marginLeft:8 },

  infoStrip:{
    flexDirection:'row',
    paddingHorizontal:12,
    paddingVertical:10,
    borderBottomWidth:1,
    borderBottomColor:BORDER,
    backgroundColor:'#fff'
  },
  stripImage:{
    width:68,
    height:88,
    resizeMode:'contain',
    marginRight:12
  },
  stripName:{ fontSize:13, fontWeight:'500', color:'#222', marginBottom:4 },
  stripPrice:{ fontSize:15, fontWeight:'700', color:'#d70018', marginBottom:4 },
  stripSupplier:{ fontSize:11, color:'#555', marginBottom:2 },
  stripColor:{ fontSize:11, color:'#333' },

  grayBody:{
    flex:1,
    backgroundColor:'#cfcfcf',
    paddingHorizontal:18,
    paddingTop:16
  },
  grayTitle:{
    fontSize:13,
    fontWeight:'500',
    color:'#222',
    marginBottom:16
  },
  colorBlock:{
    width:'100%',
    height:72,
    borderRadius:4,
    marginBottom:18,
    borderWidth:2,
    borderColor:'transparent'
  },
  colorBlockActive:{
    borderColor:'#000'
  },
  doneButton:{
    backgroundColor:'#2f65c7',
    paddingVertical:14,
    alignItems:'center',
    justifyContent:'center'
  },
  doneText:{
    color:'#fff',
    fontSize:14,
    fontWeight:'700'
  }
});
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ActivityIndicator,
  TouchableOpacity,
} from "react-native";
import Icon from "react-native-vector-icons/Ionicons";

export default function SingleProduct() {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentScreen, setCurrentScreen] = useState("main"); 

  const imageMap = {
    "black": require("./assets/vs_black.png"),
    "red": require("./assets/vs_red.png"),
    "blue": require("./assets/vs_blue.png"),
    "silver": require("./assets/vs_silver.png"),
  };

  const colorNames = {
    "black": "Đen",
    "red": "Đỏ", 
    "blue": "Xanh dương",
    "silver": "Bạc",
  };

  useEffect(() => {
    fetch("https://68d486d1214be68f8c6976f4.mockapi.io/phone")
      .then((res) => res.json())
      .then((data) => {
        const first = data[0];
        setProduct({
          ...first,
          selectedColor: first.colors[0],
        });
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const handleColorSelect = (color) => {
    setProduct((prev) => ({
      ...prev,
      selectedColor: color,
    }));
    setCurrentScreen("main"); 
  };

  const goToColorSelection = () => {
    setCurrentScreen("colorSelection");
  };

  const goBack = () => {
    setCurrentScreen("main");
  };

  if (loading || !product) {
    return <ActivityIndicator size="large" color="#0066cc" style={{ flex: 1, justifyContent: 'center' }} />;
  }

  // Màn hình chọn màu
  if (currentScreen === "colorSelection") {
    return (
      <View style={styles.container}>
        {/* Header với nút back */}
        <View style={styles.header}>
          <TouchableOpacity onPress={goBack} style={styles.backButton}>
            <Icon name="arrow-back" size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Chọn màu</Text>
        </View>

        {/* Thông tin sản phẩm nhỏ */}
        <View style={styles.productInfo}>
          <Image
            source={imageMap[product.selectedColor]}
            style={styles.smallImage}
          />
          <View style={styles.productDetails}>
            <Text style={styles.productName}>{product.name}</Text>
            <Text style={styles.productPrice}>{product.price} ₫</Text>
            <Text style={styles.supplier}>Cung cấp bởi Tiki Trading</Text>
            <Text style={styles.colorText}>Màu: {colorNames[product.selectedColor]}</Text>
            <Text style={styles.supplierLink}>Chọn màu khác</Text>
          </View>
        </View>

        {/* Danh sách màu */}
        <View style={styles.colorListContainer}>
          <Text style={styles.colorListTitle}>Chọn một màu bên dưới:</Text>
          <View style={styles.colorList}>
            {product.colors.map((color) => (
              <TouchableOpacity
                key={color}
                style={[
                  styles.colorItem,
                  { backgroundColor: color },
                  product.selectedColor === color && styles.selectedColorItem
                ]}
                onPress={() => handleColorSelect(color)}
              />
            ))}
          </View>
        </View>

        {/* Button */}
        <TouchableOpacity style={styles.doneButton}>
          <Text style={styles.doneButtonText}>XONG</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Màn hình chính
  return (
    <View style={styles.container}>
      {/* Main Product Image */}
      <View style={styles.imageContainer}>
        <Image
          source={imageMap[product.selectedColor]}
          style={styles.image}
        />
      </View>

      {/* Product Name */}
      <Text style={styles.name}>{product.name}</Text>

      {/* Star Rating */}
      <View style={styles.ratingRow}>
        {[...Array(5)].map((_, i) => (
          <Icon
            key={i}
            name={i < Math.floor(product.rate) ? "star" : "star-outline"}
            size={14}
            color="#FFD700"
          />
        ))}
        <Text style={styles.reviewText}>(Xem {Math.floor(product.rate * 100)} đánh giá)</Text>
      </View>

      {/* Prices */}
      <View style={styles.priceRow}>
        <Text style={styles.newPrice}>{product.price} ₫</Text>
        <Text style={styles.oldPrice}>1.790.000 ₫</Text>
        <View style={styles.discountBadge}>
          <Text style={styles.discountText}>-20%</Text>
        </View>
      </View>

      {/* Guarantee */}
      <View style={styles.guaranteeRow}>
        <Text style={styles.guarantee}>
          Ở ĐÂU RẺ HƠN HOÀN TIỀN
        </Text>
        <Icon name="help-circle-outline" size={16} color="#666" />
      </View>

      {/* Color Selection Button */}
      <TouchableOpacity style={styles.colorSelectionButton} onPress={goToColorSelection}>
        <Text style={styles.selectText}>4 MÀU-CHỌN MÀU</Text>
        <Icon name="chevron-forward" size={20} color="#666" />
      </TouchableOpacity>

      {/* Purchase Button */}
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f8f8",
  },
  
  // Main Screen Styles
  imageContainer: {
    alignItems: "center",
    backgroundColor: "#f8f8f8",
    borderRadius: 8,
    padding: 20,
    margin: 20,
  },
  image: {
    width: 180,
    height: 220,
    resizeMode: "contain",
  },
  name: {
    fontSize: 16,
    fontWeight: "400",
    marginBottom: 8,
    marginHorizontal: 20,
    color: "#333",
  },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
    marginHorizontal: 20,
  },
  reviewText: {
    color: "#666",
    marginLeft: 6,
    fontSize: 12,
  },
  priceRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
    marginHorizontal: 20,
  },
  newPrice: {
    color: "#e74c3c",
    fontWeight: "bold",
    fontSize: 18,
    marginRight: 15,
  },
  oldPrice: {
    textDecorationLine: "line-through",
    color: "#999",
    fontSize: 14,
    marginRight: 10,
  },
  discountBadge: {
    backgroundColor: "#e74c3c",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 3,
  },
  discountText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "bold",
  },
  guaranteeRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
    marginHorizontal: 20,
  },
  guarantee: {
    fontSize: 12,
    color: "#e74c3c",
    fontWeight: "500",
    marginRight: 5,
  },
  colorSelectionButton: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: "#eee",
    marginBottom: 20,
  },
  selectText: {
    fontSize: 14,
    fontWeight: "500",
    color: "#333",
  },
  button: {
    backgroundColor: "#e74c3c",
    borderRadius: 6,
    paddingVertical: 12,
    alignItems: "center",
    marginHorizontal: 20,
    marginBottom: 20,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
  },
  backButton: {
    padding: 5,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "500",
    marginLeft: 15,
  },
  productInfo: {
    flexDirection: "row",
    padding: 15,
    backgroundColor: "#f8f8f8",
    margin: 15,
    borderRadius: 8,
  },
  smallImage: {
    width: 80,
    height: 100,
    resizeMode: "contain",
  },
  productDetails: {
    flex: 1,
    marginLeft: 15,
  },
  productName: {
    fontSize: 14,
    fontWeight: "500",
    marginBottom: 5,
  },
  productPrice: {
    fontSize: 16,
    color: "#e74c3c",
    fontWeight: "bold",
    marginBottom: 5,
  },
  supplier: {
    fontSize: 12,
    color: "#666",
    marginBottom: 5,
  },
  colorText: {
    fontSize: 12,
    color: "#666",
    marginBottom: 5,
  },
  supplierLink: {
    fontSize: 12,
    color: "#0066cc",
  },
  colorListContainer: {
    padding: 20,
  },
  colorListTitle: {
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 15,
  },
  colorList: {
    alignItems: "flex-start",
  },
  colorItem: {
    width: 60,
    height: 60,
    marginBottom: 15,
    borderRadius: 4,
  },
  selectedColorItem: {
    borderWidth: 3,
    borderColor: "#000",
  },
  doneButton: {
    backgroundColor: "#0066cc",
    borderRadius: 6,
    paddingVertical: 12,
    alignItems: "center",
    marginHorizontal: 20,
    marginTop: "auto",
    marginBottom: 20,
  },
  doneButtonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});